import React from "react"

// List all developments available
export default function Developments() {
  return <div>index</div>
}
