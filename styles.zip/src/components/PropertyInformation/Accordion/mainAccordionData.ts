const data = [
  {
    heading: "Eligibility Criteria",
    body: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Est delectus distinctio itaque ex saepe consectetur ea aspernatur vequos, id molestiae quisquam temporibus consequatur modi unde nulla nostrum aliquam recusandae eveniet nam facere alias incidunt sit!Mollitia porro sunt quasi.",
  },
  {
    heading: "Explore the local area",
    body: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Est delectus distinctio itaque ex saepe consectetur ea aspernatur vequos, id molestiae quisquam temporibus consequatur modi unde nulla nostrum aliquam recusandae eveniet nam facere alias incidunt sit!Mollitia porro sunt quasi.",
  },
  {
    heading: "About the developer",
    body: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Est delectus distinctio itaque ex saepe consectetur ea aspernatur vequos, id molestiae quisquam temporibus consequatur modi unde nulla nostrum aliquam recusandae eveniet nam facere alias incidunt sit!Mollitia porro sunt quasi.",
  },
];

export default data;
