export default function MiddleDot() {
  return <span className="text-xl font-bold"> &#xB7; </span>
}
