import React from "react"

export default function CategoryArticlePreview() {
  return <div>CategoryArticlePreview</div>
}
