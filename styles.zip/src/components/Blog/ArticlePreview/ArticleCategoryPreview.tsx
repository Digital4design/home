import React from "react"

export default function ArticleCategoryPreview() {
  return <div>ArticleCategoryPreview</div>
}
