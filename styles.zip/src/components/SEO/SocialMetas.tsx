import React from "react"

export default function SocialMetas() {
  return <div>SocialMetas</div>
}
