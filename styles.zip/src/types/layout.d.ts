// Nav
export interface NavLinkProps {
    slug: string
    name: string
}